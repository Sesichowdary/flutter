# Reminder-Application
A simple reminder application ,A person has to reminded on the daily activities on daily basis in a span of 24 hours. 
